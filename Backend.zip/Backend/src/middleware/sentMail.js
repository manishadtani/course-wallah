import {createTransport} from 'nodemailer'

const sendEmail = async (email, subject, data) =>{
    const transport  = createTransport({
        
    })
}